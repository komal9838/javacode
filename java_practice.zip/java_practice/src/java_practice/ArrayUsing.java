package java_practice;

public class ArrayUsing {
	public static void main(String[] args) {
		int arr[] = new int[5];
		System.out.println("lenth of Array is = "+arr.length+"\n\n");
		
		for (int i=0;i<=arr.length-1;i++) {
			arr[i]=i+1;
		}
		

		for (int i=0;i<=arr.length-1;i++) {
			System.out.printf("arr[%d]",i);
			System.out.println(" = "+arr[i]+"\n");
		}
		
		
		// using while
		
		
		System.out.println("*************** Using while loop ***********");
		int start=0;
		while (start<=arr.length-1) {
			arr[start]=start+1;
			start++;
		}
		
		start =0;
		
		while (start<=arr.length-1) {
			System.out.printf("arr[%d]",start);
			System.out.println(" = "+arr[start]+"\n");
			start++;
		}
		
	}

}