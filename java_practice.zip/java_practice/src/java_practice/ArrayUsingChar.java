package java_practice;

public class ArrayUsingChar {
	public static void main(String[] args) {
		char arr[] = new char[5];
		System.out.println("length-1" + arr.length);

		for (int i = 0; i <= arr.length - 1; i++) {
			arr[i] = 'A';

		}

		for (int i = 0; i <= arr.length - 1; i++) {
			System.out.println(arr[i]);
		}
	}

}
