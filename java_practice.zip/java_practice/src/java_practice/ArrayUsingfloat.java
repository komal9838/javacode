package java_practice;

public class ArrayUsingfloat {
	public static void main(String[] args) {
		float arr[] = new float[5];
		System.out.println("length of array " +arr.length);
		
	for (int i=0; i<=arr.length-1; i++) {
		arr[i]=(i+1)*10;
		
	}
		
	for (int i=0; i<=arr.length-1; i++) {
		System.out.println(arr[i]);
	}
	}
  
}
