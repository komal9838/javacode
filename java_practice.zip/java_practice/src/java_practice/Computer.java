package java_practice;

class Computer {

	protected int add(int a, int b) {
		return a + b;

	}
}

