package java_practice;

public class House extends MethodOverloading{
	
	public static void main (String...args) {
	     int intsumresult;   
	     float floatsumresult;
	    
	     House house = new House();
	     intsumresult = house.sum(10,9);    
         floatsumresult = house.sum(1.2f,1.3f);
              
         System. out.println("Sum of two int number" + intsumresult);
         System. out.println("Sum of two float number"+ floatsumresult);
  
  }
}
