package java_practice;
/**
 * 
 * @author GNET- 22
 * this program shows example of Polymorphism or Method overloading
 */
public class MethodOverloading {
	
	public int sum(int a,int b) {
		return a+b;
	}
	
	public float sum(float a, float b) {
		return a+b;
	}
 
}
