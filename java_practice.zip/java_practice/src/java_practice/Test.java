package java_practice;

public class Test {
	
	public static void main(String...args) {
		int intsumresult;
		float floatsumresult;
		
		MethodOverloading polymorph=new MethodOverloading();
		intsumresult = polymorph.sum(5, 10);
		floatsumresult= polymorph.sum(10.5f, 0.2f);
	
		System.out.println("Sum of two integer number is "+ intsumresult);
		System.out.println("Sum of two float number is "+ floatsumresult);
		
		
		Computer computer = new Computer();
		int addresult;
		
		addresult=computer.add(56, 88);
		System.out.println(addresult);
		
	}

}
