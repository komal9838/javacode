package java_practice;

public class UsingAccessModifier {
	public static void main(String[] args) {
		int i=0;
	}
	{
		Test Test=new Test();
		System.out.println("i=5");
	}
	{
		Test Test=new Test();
		System.out.println("i=10");
		
				
	}

}
