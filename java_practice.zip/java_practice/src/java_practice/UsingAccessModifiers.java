package java_practice;

public class UsingAccessModifiers {

	public static void main(String[] args) {
		Computer computer =new Computer();
		
	}
}
