package java_practice;

public class UsingConstructor {
	
//public UsingConstructor() {
//		
//	}
//
//public UsingConstructor(String param1,String param2) {
//	
//}
	
	// this && super

}
