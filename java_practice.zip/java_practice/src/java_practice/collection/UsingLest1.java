package java_practice.collection;

import java.util.ArrayList;
import java.util.List;

public class UsingLest1 {
	public static void main(String[] arg) {
		List<Integer> list=new ArrayList();
		list.add(10);
		list.add(12);
		list.add(13);
		list.add(14);
	for(int i=0; i<list.size();i++) {
		System.out.println( list.get(i));
	}
	}

}
