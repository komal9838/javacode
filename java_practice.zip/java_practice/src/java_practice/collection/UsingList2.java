package java_practice.collection;

import java.util.ArrayList;
import java.util.List;

public class UsingList2 {
           public static void main (String[] args) {
           List<Integer> list=new ArrayList();
        	   list.add(10);
        	   list.add(20);
        	   list.add(30);
        	   list.add(40);
        	   list.add(50);
        	   list.add(60);
        	   list.add(70);
        	   list.add(80);
        	   list.add(90);
        	   list.add(100);
        	   list.add(11);
        	   list.add(122);
        	   
           for( int i=0; i<list.size();i++) {
        	   System.out.println(list.get(i));
            }
           }
}
