package java_practice.collection;

import java.util.ArrayList;
import java.util.List;

public class UsingList3 {
	public static void main(String[] args) {
		List<Integer> list= new ArrayList();
		list.add(12);
		list.add(13);
    	list.add(14);
        list.add(15);
        list.add(16);
        list.add(17);
        list.add(18);
        list.add(19);
        for ( int i=0;i<list.size();i++) {
        	System.out.println(list.get(i));
        }

	}

}
