package java_practice.collection;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;

import java_practice.inheritance.Book;

public class UsingMap {
	
	public static void main(String[] args) {
		//usingHashMap();
		
		usingConcurrentHashMap();
		
		
	}

	private static void usingConcurrentHashMap() {
		Book book=new Book();
		book.setAuthor("James Gosling");
		book.setBookName("Java book");
		ConcurrentHashMap<Integer, Book> concurrentHashMap= new ConcurrentHashMap<>();
		concurrentHashMap.put(1, book);
		
		Iterator iterator= concurrentHashMap.entrySet().iterator();
		while (iterator.hasNext()) {
			Map.Entry<Integer, Book> entry= (Map.Entry<Integer, Book>)iterator.next();
			concurrentHashMap.remove(1);
			System.out.println(entry.getKey() +"\t" + entry.getValue());
		}
	}

	private static void usingHashMap() {
		Map<Integer,String> hashMap=new HashMap();
		hashMap.put(1, "A");
		hashMap.put(2, "B");
		hashMap.put(3, "C");
		
		Iterator iterator= hashMap.entrySet().iterator();
		while (iterator.hasNext()) {
			Map.Entry<Integer, String> entrySet= (Entry<Integer, String>) iterator.next();
			//hashMap.remove(1);
			System.out.println(entrySet.getKey() +"\t" + entrySet.getValue());
		}
	}

}
