package java_practice.collection;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class UsingSet {
	
	public static void main(String[] args) {
		Set<Integer> mySet=new HashSet();
		mySet.add(1);
		mySet.add(2);
		mySet.add(3);
		mySet.add(4);
		mySet.add(4);
		mySet.remove(2);
		
	   Iterator iterator= mySet.iterator();
	   while(iterator.hasNext()) {
		   System.out.println(iterator.next());
	   }
		
	}

}
