package java_practice.collection;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class UsingSet2 {
	public static void main(String[] args) {
		Set<Integer>mySet=new HashSet();
		mySet.add(11);
		mySet.add(12);
		mySet.add(13);
		mySet.add(14);
		mySet.add(14);
		mySet.remove(12);
		Iterator interator=mySet.iterator();
		while(interator.hasNext()) {
			System.out.println(interator.next());
			}
	}

}

