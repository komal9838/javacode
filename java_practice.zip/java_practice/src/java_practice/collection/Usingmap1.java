package java_practice.collection;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;

import java_practice.inheritance.Pens;


public class Usingmap1  {  

//     public static void main (String[] args) {
//		//usingHashMap();
//    	 
//		usingConcurrentHashMap();  
//		
//     }	
		
	private static void usingConcurrentHashMap() {
		Pens pens=new Pens();
		pens.setAuthor("black");
		pens.setBookName("blue pens");
        ConcurrentHashMap<Integer, Pens> concurrentHashMap= new ConcurrentHashMap<>();
		concurrentHashMap.put(2, pens);
		
	Iterator iterator= concurrentHashMap.entrySet().iterator();
    while (iterator.hasNext()) {
			Map.Entry<Integer, Pens> entry= (Map.Entry<Integer, Pens>)iterator.next();
			concurrentHashMap.remove(1);
			System.out.println(entry.getKey() +"\t" + entry.getValue());
		}
	}
	
	public static void main(String[] args) {
		Map<Integer, String>hashmap=new HashMap();
		hashmap.put(1,"A");
		hashmap.put(2,"S");
		hashmap.put(3,"Z");
	
		Iterator iterator =hashmap.entrySet().iterator();
		while( iterator.hasNext()) {
			Map.Entry<Integer, String> entrySet = (Entry<Integer,  String>) iterator.next();
			//hashMap.remove(2);
			System.out.println(entrySet.getKey()+"\t" +entrySet.getValue());
			
		}
		
	}

}
