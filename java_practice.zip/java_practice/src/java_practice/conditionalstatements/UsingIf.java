package java_practice.conditionalstatements;

public class UsingIf {
	
	public static void main(String[] args) {
		int a=10;
		int b=20;
		if (a>b) {
			System.out.println("A is greater");
		}else {
			System.out.println("B is greater");
		}
	}

}
