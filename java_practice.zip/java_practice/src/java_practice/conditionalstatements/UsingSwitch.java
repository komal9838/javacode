package java_practice.conditionalstatements;

public class UsingSwitch {

	public static void main(String[] args) {
		int a = 10;
		switch (a) {
		case 10:
			System.out.println("Value has been matched");
			break;
			
		case 8:
			System.out.println("Value is not 10");
			break;

		default:
			System.out.println("Value did not match");
			break;
		}
	}

}
