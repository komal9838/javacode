package java_practice.exceptions;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class ExceptionExample {

	public void readFile(String fileName) throws IOException {
		File file=new File(fileName);
		BufferedReader br=null;
			FileReader fr=new FileReader(file);
			br= new BufferedReader(fr);
			String data="";
			while ((data=br.readLine())!=null) {
				System.out.println(data);
			}
			br.close();
		
		
	}
}
