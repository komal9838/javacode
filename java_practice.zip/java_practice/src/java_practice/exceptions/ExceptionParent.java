package java_practice.exceptions;

import java.io.IOException;

public class ExceptionParent {
	
	public static void main(String[] args) {
		
		ExceptionExample exceptionExample = new ExceptionExample();
		try {
			System.out.println("Reading file 1..................");
			exceptionExample.readFile("test.txt");
			System.out.println("Reading file 2..................");
			exceptionExample.readFile("test1.txt");
		} catch (IOException e) {
			System.out.println("looks like a error happened check the file path correctly"+e.getMessage());
		}
	}

}
