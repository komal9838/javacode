package java_practice.exceptions;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class UsingTryCatch {

	public static void main(String[] args) {
		try {
		float result = 10/0;
		System.out.println(result);
     
		}catch(ArithmeticException exception) {
			System.out.println("Can't calculate the result");

		}catch (Exception e) {
			// TODO: handle exception
		}finally {
			System.out.println("transaction can't be completed saved in db for rollback.");
		}
		
		
		File file = new File("C:\\abc.txt");
		try {
			FileInputStream fis=new FileInputStream(file);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
