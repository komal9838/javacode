package java_practice.increments;

public class PostAndPreIncrement {
	
	public static void main(String[] args) {
		int i=10;
		// pre-increment increments the value and uses same time
		System.out.println(++i);
		System.out.println(i);
		
		
		// post increment first uses the old value then increments.
		i=10;
		System.out.println(i++);
		System.out.println(i);
		
	}

}
