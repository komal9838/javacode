package java_practice.inheritance;

import java.util.Objects;

public class Book {
	
	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

	private String bookName;
	private String author;
	@Override
	public int hashCode() {
		return Objects.hash(author, bookName);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Book other = (Book) obj;
		return Objects.equals(author, other.author) && Objects.equals(bookName, other.bookName);
	}

	public static void main(String[] args) {
		  Book book=new Book();
		  System.out.println(book.hashCode());
	
	}
	
	    public void getBookName() {
		System.out.println("java");
	}
	
}
