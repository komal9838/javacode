package java_practice.inheritance;

/**
 * 
 * @author GNET- 22
 * This class demo's feature of Inheritance.
 * Java doesn't supports multiple inheritance You can only extend one class at a time
 */
public class Child extends Parent{

}
