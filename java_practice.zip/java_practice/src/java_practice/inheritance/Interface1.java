package java_practice.inheritance;

public interface Interface1 {

}
