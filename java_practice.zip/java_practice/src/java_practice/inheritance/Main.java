package java_practice.inheritance;

public class Main {
	
	public static void main(String[] args) {
		Parent parent=new Parent();
		Child child =new Child();
		
		parent.getClassName();
		child.getClassName();
	}

}
