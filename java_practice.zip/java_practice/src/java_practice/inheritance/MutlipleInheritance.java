package java_practice.inheritance;

public class MutlipleInheritance implements Interface1, Interface2 {
	

}
