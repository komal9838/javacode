package java_practice.inheritance;

public class Parent {

	public void getClassName() {
		System.out.println(this.getClass().getName());
	}

}
