package java_practice.inheritance;

public class Parent1 {
	
	public float sum(float a, float b) {
		return a+b;
	}

}
