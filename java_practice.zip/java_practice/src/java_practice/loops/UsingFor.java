package java_practice.loops;


/**
 * 
 * @author GNET- 22
 * WAP to print table of 2 using for loop.
 */
public class UsingFor {
	
	public static void main(String[] args) {
		originalFor();
		practiceFor();
		
	}

	private static void practiceFor() {
		for (int i=3;i<13;i++) {
			System.out.println(" 3 x" +i+ "=" +2*i );
		}
		
	}

	private static void originalFor() {
		for (int i=1; i<11;i++) {
			System.out.println("2 X "+i + " = "+2*i);
		}
	}

}
