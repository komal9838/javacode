package java_practice.loops;

public class UsingWhile {
	
	
	public static void main(String[] args) {
		 int i=1;
		 
		 while (i<11) {
				System.out.println("2 X "+i + " = "+2*i);
				i++;

		 }
	}

}
