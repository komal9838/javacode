package java_practice.loops;

public class WhileUshing {
	public static void main(String[] args) {
       int i=4;
       
	    while (i<13){
	    	
	     System.out.println("2 X "+i + " = "+2*i);
	     i++;
	    }
	}
}
