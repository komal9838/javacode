/**
 * 
 */
package java_practice.sorting;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * @author GNET- 22
 *
 */
public class NaturalSort {
	
	public static void main(String[] args) {
//		List<String> myList=new ArrayList<String>();
//		myList.add("Banana");
//		myList.add("Apple");
//		myList.add("Grapes");
		
		/**
		 * Below code shows sorting using @link{Comparable} interface.
		 */
		List<Student> myList=new ArrayList<Student>();
		myList.add(new Student(4, "A",23 ));
		myList.add(new Student(3, "B",20 ));
		myList.add(new Student(2, "C",18 ));
		myList.add(new Student(1, "D",19 ));
		
		Collections.sort(myList);
		
		myList.stream().forEach(record->{
			System.out.println(record);
		});
		
	}

}
