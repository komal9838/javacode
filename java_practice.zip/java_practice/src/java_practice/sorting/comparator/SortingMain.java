package java_practice.sorting.comparator;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class SortingMain {
	
	public static void main(String[] args) {
		List<Student> myList=new ArrayList<Student>();
		myList.add(new Student(4, "A",23 ));
		myList.add(new Student(3, "B",20 ));
		myList.add(new Student(2, "C",18 ));
		myList.add(new Student(1, "D",19 ));
		Collections.sort(myList, new AgeComparator());
		myList.stream().forEach(record->{
			System.out.println(record);
		});
		
	}

}
