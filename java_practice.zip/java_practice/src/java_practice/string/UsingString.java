package java_practice.string;

public class UsingString {

	public static void main(String[] args) {
		String name="";
		name="GNET";
		name=name + "Lucknow";
		System.out.println(name);
		
				
		StringBuffer sb=new StringBuffer();
	
		StringBuilder builder=new StringBuilder();
		builder.append("GNET");
		builder.append("Lucknow");
	     
		System.out.println(builder);
		
	}
}
