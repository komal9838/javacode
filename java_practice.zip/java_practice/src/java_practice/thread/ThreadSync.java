package java_practice.thread;

public class ThreadSync extends Thread {

	static int count = 0;

	public static void main(String[] args) {
	
		Thread t1 = new ThreadSync();
		t1.setName("Thread 1");

		Thread t2 = new ThreadSync();
		t2.setName("Thread 2");
		t1.start();
		t2.start();
		
	}

	public void run() {
        if (Thread.currentThread().getName().equalsIgnoreCase("Thread 1")) {
        	try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        }
		System.out.println(Thread.currentThread().getPriority() + " value  of count " + count++);
	}
}
