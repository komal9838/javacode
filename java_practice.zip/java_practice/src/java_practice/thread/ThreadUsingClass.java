package java_practice.thread;

public class ThreadUsingClass {
	
	public static void main(String[] args) throws InterruptedException {
		System.out.println("Line no 6 proccessed");
		new ThreadUsingClass().processTransaction();
		System.out.println("Line no 8 proccessed");
	}

	private  void processTransaction() throws InterruptedException {
		Thread thread= new Thread(new Runnable() {
			
			@Override
			public void run() {
				for (int i=1;i<=10;i++) {
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					System.out.println("Transaction "+ i +" proccesed");
				}
				System.out.println("line no 7 proccessed");
				
			}
		}, "My Thread");
		thread.start();
	}

}
