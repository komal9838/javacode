package java_practice.thread;

public class ThreadUsingRunnable implements Runnable{

	public static void main(String[] args) {
		Thread t=new Thread(new ThreadUsingRunnable());
		t.start();
	}
	@Override
	public void run() {
		System.out.println(Thread.activeCount());
		for (int i=1;i<=10;i++) {
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("Transaction "+ i +" proccesed");
		}
		
	}

}
