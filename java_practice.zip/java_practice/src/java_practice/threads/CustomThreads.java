package java_practice.threads;

public class CustomThreads implements Runnable{

	public static void main(String[] args) {
		while(true) {
			Thread t=new Thread(new CustomThreads());
			t.start();
		}
	}
	@Override
	public void run() {
		
		System.out.println("Thread has been started");
		try {
			Thread.sleep(1000000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
