package java_practice;

public class threeifnumber {
	public static void main(String[] args) {
		int a=10,b=20,c=30;
		if(a>b)
		{
			System.out.println("a is greater");
		}else {
			System.out.println(" b is greater");
		}
		if (a>c) {
			System.out.println(" b is greater ");
		}else {
			System.out.println(" c is greater");
		}
	}

}
