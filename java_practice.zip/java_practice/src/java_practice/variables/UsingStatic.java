package java_practice.variables;

public class UsingStatic {
	
	public static void main(String[] args) {
		System.out.println(VariableScope.value);
	}

}
