package java_practice.variables;

public class VariableScope {
	static int value=10;
	
    public static void main(String[] args) {
    	
    	VariableScope variableScope= new VariableScope();
    	variableScope.value=5;
    	System.out.println(variableScope.value);
    	
    	VariableScope variableScope1= new VariableScope();
    	System.out.println(variableScope1.value);
    	
    	
		
	}
    
    
  

}
